package view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Module;
import model.Schedule;

public class ReserveModulesTerm2Pane extends GridPane {
	
	private ListView<Module> uSecondTermModules;
	private ListView<Module> rSecondTermModules;
	private ObservableList<Module> modulesUSecondTerm;
	private ObservableList<Module> modulesRSecondTerm;
	private Button btnAddReserveSecond;
	private Button btnRemoveReserveSecond;
	private Button btnConfirmReserveSecond;
	
	ArrayList<Module> listUSecond = new ArrayList<Module>();
	ArrayList<Module> listRSecond = new ArrayList<Module>();
	
	public ReserveModulesTerm2Pane(){
		this.setVgap(20);
		this.setHgap(20);
		this.setPadding(new Insets(20));

		uSecondTermModules = new ListView<Module>();
		rSecondTermModules = new ListView<Module>();
		
		modulesUSecondTerm = FXCollections.observableArrayList(listUSecond);
		modulesRSecondTerm = FXCollections.observableArrayList(listRSecond);
		
		
		uSecondTermModules.setItems(modulesUSecondTerm);
		rSecondTermModules.setItems(modulesRSecondTerm);
		
		uSecondTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		rSecondTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		uSecondTermModules.setPrefSize(500, 400);
		rSecondTermModules.setPrefSize(500, 400);
		
		Label lblReserveSecond = new Label("Reserve 30 credits of term 2 modules");
		Label lblUSecond = new Label("Unselected Term 2 modules");
		Label lblRSecond = new Label("Reserved Term 2 modules");
		
		btnAddReserveSecond = new Button ("add");
		btnRemoveReserveSecond = new Button ("remove");
		btnConfirmReserveSecond = new Button ("confirm");
		
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setPercentWidth(50);
		
		ColumnConstraints column2 = new ColumnConstraints();
		column2.setPercentWidth(50);
		
		RowConstraints row1 = new RowConstraints();
		row1.setPercentHeight(90);
		
		RowConstraints row2 = new RowConstraints();
		row2.setPercentHeight(10);
		
		this.getColumnConstraints().addAll(column1,column2);
		this.getRowConstraints().addAll(row1,row2);
		
		VBox.setVgrow(uSecondTermModules, Priority.ALWAYS);
		VBox.setVgrow(rSecondTermModules, Priority.ALWAYS);

		//create Vbox1
		VBox vbox1 = new VBox(8);
		vbox1.setPadding(new Insets(10));
		vbox1.setAlignment(Pos.CENTER_LEFT);
		
		vbox1.getChildren().addAll(lblUSecond,uSecondTermModules);
		
		//create Vbox2
		VBox vbox2 = new VBox(8);
		vbox2.setPadding(new Insets(10));
		vbox2.setAlignment(Pos.CENTER_LEFT);
		
		vbox2.getChildren().addAll(lblRSecond,rSecondTermModules);
		

		
		//create HBox1
		HBox hbox1 = new HBox(8);
		hbox1.setPadding(new Insets(10));
		hbox1.setAlignment(Pos.CENTER_RIGHT);
		
		hbox1.getChildren().addAll(lblReserveSecond,btnAddReserveSecond,btnRemoveReserveSecond,btnConfirmReserveSecond);


		this.add(vbox1, 0, 0);
		this.add(vbox2, 1, 0);
		this.add(hbox1, 0, 1);
}
	
	public Module getUnselectedSecond() {
		return uSecondTermModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getReservedSecond() {
		return rSecondTermModules.getSelectionModel().getSelectedItem();
	}
	
	public void addSecondTermReserveModules(Module module) {
		modulesRSecondTerm.add(module);
		modulesUSecondTerm.remove(module);
	}
	
	
	public void removeSecondTermReserveModules(Module module) {
		modulesUSecondTerm.add(module);
		modulesRSecondTerm.remove(module);
	}
	
	public Set<Module> confirmSecondTermReserveModules() {
		Set<Module> reservedModules;
		reservedModules = new TreeSet<Module>();

			for (Module m: modulesRSecondTerm) {
				reservedModules.add(m);
			}
		return reservedModules;
	}
	
	public int getCredits() {
		int credits = 0;
		
		for (Module i: modulesRSecondTerm) {
			credits = credits + i.getModuleCredits();
		}
		return credits;
	}
	
	public void addModulesToListView(Collection<Module> Course, Set<Module> selectedModules) {
		modulesUSecondTerm.addAll(Course);
		modulesUSecondTerm.removeIf(m -> m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_2));
		modulesUSecondTerm.removeIf(m -> selectedModules.contains(m));
	}
	
	public void loadMoulesToListView(Set<Module> reservedModules) {
		modulesUSecondTerm.removeIf(m -> reservedModules.contains(m));
		modulesRSecondTerm.addAll(reservedModules);
		modulesRSecondTerm.removeIf(m -> !m.getDelivery().equals(Schedule.TERM_2));
	}
	
	public void clearContent() {
		modulesUSecondTerm.clear();
	}
	
	
	public void addAddReserveSecondHandler(EventHandler<ActionEvent> handler) {
		btnAddReserveSecond.setOnAction(handler);
	}
	
	public void addRemoveReserveSecondHandler(EventHandler<ActionEvent> handler) {
		btnRemoveReserveSecond.setOnAction(handler);
	}
	
	public void addSubmitReserveSecondHandler(EventHandler<ActionEvent> handler) {
		btnConfirmReserveSecond.setOnAction(handler);
	}
	
}
