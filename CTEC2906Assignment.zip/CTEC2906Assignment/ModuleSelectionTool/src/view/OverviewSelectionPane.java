package view;

import java.util.ArrayList;
import java.util.Set;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Module;
import model.StudentProfile;

public class OverviewSelectionPane extends GridPane {

	private ListView<String> studentProfile;
	private ListView<String> selectedModules;
	private ListView<String> reservedModules;
	private ObservableList<String> oStudentProfile;
	private ObservableList<String> oSelectedModules;
	private ObservableList<String> oReservedModules;
	private Button btnSaveOverview;
	
	ArrayList<String> lStudentProfile = new ArrayList<String>();
	ArrayList<String> lSelectedModules = new ArrayList<String>();
	ArrayList<String> lReservedModules = new ArrayList<String>();
	
	public OverviewSelectionPane() {
		this.setVgap(20);
		this.setHgap(20);
		this.setPadding(new Insets(20));
		
		studentProfile = new ListView<String>();
		selectedModules = new ListView<String>();
		reservedModules = new ListView<String>();
		
		oStudentProfile = FXCollections.observableArrayList(lStudentProfile);
		oSelectedModules = FXCollections.observableArrayList(lSelectedModules);
		oReservedModules = FXCollections.observableArrayList(lReservedModules);
		
		studentProfile.setItems(oStudentProfile);
		selectedModules.setItems(oSelectedModules);
		reservedModules.setItems(oReservedModules);
		
		studentProfile.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		selectedModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		reservedModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		studentProfile.setPrefSize(500, 200);
		selectedModules.setPrefSize(500, 400);
		reservedModules.setPrefSize(500, 400);
		
		btnSaveOverview = new Button("Save Overview");
		
		btnSaveOverview.setAlignment(Pos.BOTTOM_CENTER);
		
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setPercentWidth(50);
		
		ColumnConstraints column2 = new ColumnConstraints();
		column2.setPercentWidth(50);
		
		RowConstraints row1 = new RowConstraints();
		row1.setPercentHeight(30);
		
		RowConstraints row2 = new RowConstraints();
		row2.setPercentHeight(60);
		
		RowConstraints row3 = new RowConstraints();
		row3.setPercentHeight(10);
		
		this.getColumnConstraints().addAll(column1,column2);
		this.getRowConstraints().addAll(row1,row2,row3);
		
		//create hbox1
		//HBox hbox1 = new HBox(8);
		//hbox1.minHeight(20);
		//hbox1.setAlignment(Pos.CENTER);
		
		this.add(studentProfile, 0, 0, 2, 1);
		this.add(selectedModules, 0, 1);
		this.add(reservedModules, 1, 1);
		this.add(btnSaveOverview, 0, 2, 2, 1);

	}
	
	public void addStudentToListView(StudentProfile student) {
		oStudentProfile.add("Name: " + student.getStudentName());
		oStudentProfile.add("PNumber: " + student.getStudentPnumber());
		oStudentProfile.add("Email: " + student.getStudentEmail());
		oStudentProfile.add("Date: " +  student.getSubmissionDate().toString());
		oStudentProfile.add("Course: " + student.getStudentCourse().toString());
			}
	
	public void addSelectedModulesToListView(Set<Module> selectedModules) {
		oSelectedModules.add("Selected Modules: ");
		oSelectedModules.add("------------------");
		for (Module m: selectedModules) {
		oSelectedModules.add(m.toString());
		}
	}
	
	public void addReservedModulesToListView(Set<Module> ReservedModules) {
		oReservedModules.add("Reserved Modules: ");
		oReservedModules.add("------------------");
		for (Module m: ReservedModules) {
		oReservedModules.add(m.toString());
		}
	}
	
	public void clearContent() {
		oStudentProfile.clear();
		oSelectedModules.clear();
		oReservedModules.clear();
	}
	
	public void addSaveOverview(EventHandler<ActionEvent> handler) {
		btnSaveOverview.setOnAction(handler);
	}
}
