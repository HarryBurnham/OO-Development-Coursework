package view;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Module;
import model.Schedule;


public class ModuleSelectionPane extends GridPane {
	
	private ListView<Module> uFirstTermModules;
	private ListView<Module> uSecondTermModules;
	private ListView<Module> sYearLongModules;
	private ListView<Module> sFirstTermModules;
	private ListView<Module> sSecondTermModules;
	private ObservableList<Module> modulesUFirstTerm;
	private ObservableList<Module> modulesUSecondTerm;
	private ObservableList<Module> modulesYearLong;
	private ObservableList<Module> modulesFirstTerm;
	private ObservableList<Module> modulesSecondTerm;
	private Button btnAddFirst;
	private Button btnRemoveFirst;
	private Button btnAddSecond;
	private Button btnRemoveSecond;
	private Button btnReset;
	private Button btnSubmit;
	private TextField txtCreditsFirst, txtCreditsSecond;
	
	ArrayList<Module> listUFirst = new ArrayList<>();
	ArrayList<Module> listUSecond = new ArrayList<>();
	ArrayList<Module> mYearList = new ArrayList<>();
	ArrayList<Module> mFirstTermList = new ArrayList<>();
	ArrayList<Module> mSecondTermList = new ArrayList<>();
	
	public ModuleSelectionPane(){
		this.setVgap(20);
		this.setHgap(20);
		this.setPadding(new Insets(20));

		uFirstTermModules = new ListView<Module>();
		uSecondTermModules = new ListView<Module>();
		sYearLongModules = new ListView<Module>();
		sFirstTermModules = new ListView<Module>();
		sSecondTermModules = new ListView<Module>();
		
		modulesUFirstTerm = FXCollections.observableArrayList(listUFirst);
		modulesUSecondTerm = FXCollections.observableArrayList(listUSecond);
		modulesYearLong = FXCollections.observableArrayList(mYearList);
		modulesFirstTerm = FXCollections.observableArrayList(mFirstTermList);
		modulesSecondTerm = FXCollections.observableArrayList(mSecondTermList);
		
		uFirstTermModules.setItems(modulesUFirstTerm);
		uSecondTermModules.setItems(modulesUSecondTerm);
		sYearLongModules.setItems(modulesYearLong);
		sFirstTermModules.setItems(modulesFirstTerm);
		sSecondTermModules.setItems(modulesSecondTerm);
		
		uFirstTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		uSecondTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		sYearLongModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		sFirstTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		sSecondTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		uFirstTermModules.setPrefSize(400,150);
		uSecondTermModules.setPrefSize(400,150);
		sYearLongModules.setPrefSize(400, 125);
		sFirstTermModules.setPrefSize(400,150);
		sSecondTermModules.setPrefSize(400,150);
		
		Label lblUnselectedFirst = new Label ("Unselected Term 1 Modules");
		Label lblUnselectedSecond= new Label ("Unselected Term 2 Modules");
		Label lblSelectedYear = new Label ("Selected Year Long Modules");
		Label lblSelectedFirst = new Label ("Selected Term 1 Modules");
		Label lblSelectedSecond = new Label ("Selected Term 2 Modules");
		Label lblCreditsFirst = new Label ("Current Term 1 Credits: ");
		Label lblCreditsSecond = new Label ("Current Term 2 Credits: ");
		Label lblTerm1 = new Label("Term 1 ");
		Label lblTerm2 = new Label("Term 2");
		
		btnAddFirst = new Button ("Add");
		btnRemoveFirst = new Button ("Remove");
		btnAddSecond = new Button ("Add");
		btnRemoveSecond = new Button ("Remove");
		btnReset = new Button("Reset");
		btnSubmit = new Button("Submit");
		
		txtCreditsFirst = new TextField();
		txtCreditsSecond = new TextField();
		
		txtCreditsFirst.setPrefSize(40, 20);
		txtCreditsSecond.setPrefSize(40, 20);
		
		txtCreditsFirst.setText("0");
		txtCreditsSecond.setText("0");
		
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setPercentWidth(45);
		
		ColumnConstraints column2 = new ColumnConstraints();
		column2.setPercentWidth(10);
		
		ColumnConstraints column3 = new ColumnConstraints();
		column3.setPercentWidth(45);
		
		RowConstraints row1 = new RowConstraints();
		row1.setPercentHeight(30);
		
		RowConstraints row2 = new RowConstraints();
		row2.setPercentHeight(10);
		
		RowConstraints row3 = new RowConstraints();
		row3.setPercentHeight(30);
		
		RowConstraints row4 = new RowConstraints();
		row4.setPercentHeight(10);
		
		RowConstraints row5 = new RowConstraints();
		row5.setPercentHeight(10);
		
		RowConstraints row6 = new RowConstraints();
		row6.setPercentHeight(10);
		
		this.getColumnConstraints().addAll(column1,column2,column3);
		this.getRowConstraints().addAll(row1,row2,row3,row4,row5,row6);
		
		VBox.setVgrow(uFirstTermModules, Priority.ALWAYS);
		VBox.setVgrow(uSecondTermModules, Priority.ALWAYS);
		VBox.setVgrow(sYearLongModules, Priority.SOMETIMES);
		VBox.setVgrow(sFirstTermModules, Priority.ALWAYS);
		VBox.setVgrow(sSecondTermModules, Priority.ALWAYS);
		
				//create hbox1
				HBox hbox1 = new HBox(8);
				hbox1.setPadding(new Insets(10));
				hbox1.minHeight(20);
				hbox1.setAlignment(Pos.CENTER);
				
				hbox1.getChildren().addAll(lblTerm1,btnAddFirst,btnRemoveFirst);

				//create hbox2
				HBox hbox2 = new HBox(8);
				hbox2.setPadding(new Insets(10));
				hbox2.minHeight(20);
				hbox2.setAlignment(Pos.CENTER);
				
				hbox2.getChildren().addAll(lblTerm2,btnAddSecond,btnRemoveSecond);	
				
		
				//create hbox3 
				HBox hbox3 = new HBox(8); 
				hbox3.setPadding(new Insets(10));
				hbox3.minHeight(20); 
				hbox3.setAlignment(Pos.BOTTOM_CENTER);
		  
				hbox3.getChildren().addAll(lblCreditsFirst,txtCreditsFirst);
				
				//create hbox4
				HBox hbox4 = new HBox(8); 
				hbox4.setPadding(new Insets(10));
				hbox4.minHeight(20); 
				hbox4.setAlignment(Pos.BOTTOM_CENTER);
		  
				hbox4.getChildren().addAll(lblCreditsSecond,txtCreditsSecond);
				
				//create hbox5
				HBox hbox5 = new HBox(8);
				hbox5.setPadding(new Insets(10));
				hbox5.minHeight(20);
				hbox5.setAlignment(Pos.BOTTOM_CENTER);
				
				hbox5.getChildren().addAll(btnReset,btnSubmit);
			
				//create vbox1
				VBox vbox1 = new VBox(8);
				vbox1.setPadding(new Insets(10));
				vbox1.setMinHeight(200);
				vbox1.setAlignment(Pos.TOP_LEFT);
				
				vbox1.getChildren().addAll(lblUnselectedFirst, uFirstTermModules);
				
				//create vbox2
				VBox vbox2 = new VBox(8);
				vbox2.setPadding(new Insets(10));
				vbox2.setMinHeight(200);
				vbox2.setAlignment(Pos.BOTTOM_LEFT);
				
				vbox2.getChildren().addAll(lblUnselectedSecond,uSecondTermModules);
				
				//create vbox3
				VBox vbox3 = new VBox(8);
				vbox3.setPadding(new Insets(10));
				vbox3.setMinHeight(400);
				
				vbox3.getChildren().addAll(lblSelectedYear,sYearLongModules,lblSelectedFirst, sFirstTermModules, lblSelectedSecond, sSecondTermModules);
				
				this.add(vbox1, 0, 0);
				this.add(hbox1, 0, 1);
				this.add(vbox2, 0, 2);
				this.add(hbox2, 0, 3);
				this.add(hbox3, 0, 4);
				this.add(hbox4, 2, 4);
				this.add(hbox5, 1, 5);
				this.add(vbox3, 2, 0, 1, 4);
		
				this.setWidth(1800);
				this.setHeight(1600);
		
	}
	
	public Module getUnselectedFirst() {
		return uFirstTermModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getUnselectedSecond() {
		return uSecondTermModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getSelectedYearLong() {
		return sYearLongModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getSelectedFirst() {
		return sFirstTermModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getSelectedSecond() {
		return sSecondTermModules.getSelectionModel().getSelectedItem();
	}
	
	public void clearContent() {
		modulesUFirstTerm.clear();
		modulesUSecondTerm.clear();
		modulesYearLong.clear();
		modulesFirstTerm.clear();
		modulesSecondTerm.clear();
	}
	
	public void addFirstTermModule(Module module) {
		modulesFirstTerm.add(module);
		modulesUFirstTerm.remove(module);
	}
	
	public void addSecondTermModule(Module module) {
		modulesSecondTerm.add(module);
		modulesUSecondTerm.remove(module);
	}
	
	public void removeFirstTermModule(Module module) {
		if (module.isMandatory() == false) {
		modulesUFirstTerm.add(module);
		modulesFirstTerm.remove(module);
		}
	}
	
	public void removeSecondTermModule(Module module) {
		if (module.isMandatory() == false) {
		modulesUSecondTerm.add(module);
		modulesSecondTerm.remove(module);
		}
	}
	
	public int creditsFirst() {
		int credits = 0;
		String s ="";
		
		for(Module i : modulesFirstTerm) {
			 credits = credits + (i.getModuleCredits());
		}
		
		for(Module i : modulesYearLong) {
			credits = credits + (i.getModuleCredits()/2);
		}
		
		s = Integer.toString(credits);
		txtCreditsFirst.setText(s);
		return credits;
	}
	
	public int creditsSecond() {
		int credits = 0;
		String s ="";
		
		for(Module i : modulesSecondTerm) {
			 credits = credits + (i.getModuleCredits());
		}
		
		for(Module i : modulesYearLong) {
			credits = credits + (i.getModuleCredits()/2);
		}
		
		s = Integer.toString(credits);
		txtCreditsSecond.setText(s);
		return credits;
	}
	
	public Set<Module> setModules() {

		Set<Module> selectedModules;
		
		selectedModules = new TreeSet<Module>();
		
			
			for(Module i: modulesYearLong) {
				selectedModules.add(i);
			}
			
			for (Module j: modulesFirstTerm) {
				selectedModules.add(j);
			}
			
			for (Module k: modulesSecondTerm) {
				selectedModules.add(k);
			}
		return selectedModules;
	}
	
	public void addModulesToListView(Collection<Module> Course) {
		modulesUFirstTerm.addAll(Course);
		modulesUFirstTerm.removeIf(m -> m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_1));
		
		modulesUSecondTerm.addAll(Course);
		modulesUSecondTerm.removeIf(m -> m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_2));
		
		modulesYearLong.addAll(Course);
		modulesYearLong.removeIf(m -> !m.isMandatory() || !m.getDelivery().equals(Schedule.YEAR_LONG));
		
		modulesFirstTerm.addAll(Course);
		modulesFirstTerm.removeIf(m -> !m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_1));
		
		modulesSecondTerm.addAll(Course);
		modulesSecondTerm.removeIf(m -> !m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_2));
	}
	
	public void LoadModulesToListView(Set<Module> selectedModules) {
		modulesUFirstTerm.removeIf(m -> selectedModules.contains(m));
		
		modulesUSecondTerm.removeIf(m -> selectedModules.contains(m));

		modulesYearLong.addAll(selectedModules);
		modulesYearLong.removeIf(m -> !m.getDelivery().equals(Schedule.YEAR_LONG));
		
		modulesFirstTerm.addAll(selectedModules);
		modulesFirstTerm.removeIf(m -> !m.getDelivery().equals(Schedule.TERM_1));
		
		modulesSecondTerm.addAll(selectedModules);
		modulesSecondTerm.removeIf(m -> !m.getDelivery().equals(Schedule.TERM_2));
		
	}

public void addSubmitHandler(EventHandler<ActionEvent> handler) {
	btnSubmit.setOnAction(handler);
}

public void addResetHandler(EventHandler<ActionEvent> handler) {
	btnReset.setOnAction(handler);
}

public void addAddFirstHandler(EventHandler<ActionEvent> handler) {
	btnAddFirst.setOnAction(handler);
}

public void addAddSecondHandler(EventHandler<ActionEvent> handler) {
	btnAddSecond.setOnAction(handler);
}

public void addRemoveFirstHandler(EventHandler<ActionEvent> handler) {
	btnRemoveFirst.setOnAction(handler);
}

public void addRemoveSecondHandler(EventHandler<ActionEvent> handler) {
	btnRemoveSecond.setOnAction(handler);
}
	
}
	