package view;

import javafx.scene.control.Accordion;

import javafx.scene.control.TitledPane;

public class ReserveModulesPane extends Accordion {

	private ReserveModulesTerm1Pane rmf;
	private ReserveModulesTerm2Pane rms;
	private TitledPane t1, t2;
	
	public ReserveModulesPane() {
		
		rmf = new ReserveModulesTerm1Pane();
		rms = new ReserveModulesTerm2Pane();
		
		t1 = new TitledPane("Term 1 modules",rmf);
		t2 = new TitledPane("Term 2 modules",rms);
		
		this.getPanes().addAll(t1,t2);
		
		this.setExpandedPane(t1);
	}
	
	public ReserveModulesTerm1Pane getReserveModulesTerm1Pane() {
		return rmf;
	}
	
	public ReserveModulesTerm2Pane getReserveModulesTerm2Pane() {
		return rms;
	}
	
	public void changePane() {
		this.setExpandedPane(t2);
	}
	
}
