package view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Module;
import model.Schedule;

public class ReserveModulesTerm1Pane extends GridPane {
	
	private ListView<Module> uFirstTermModules;
	private ListView<Module> rFirstTermModules;
	private ObservableList<Module> modulesUFirstTerm;
	private ObservableList<Module> modulesRFirstTerm;
	private Button btnAddReserveFirst;
	private Button btnRemoveReserveFirst;
	private Button btnConfirmReserveFirst;
	
	ArrayList<Module> listUFirst = new ArrayList<Module>();
	ArrayList<Module> listRFirst = new ArrayList<Module>();
	
	public ReserveModulesTerm1Pane(){
		this.setVgap(20);
		this.setHgap(20);
		this.setPadding(new Insets(20));

		uFirstTermModules = new ListView<Module>();
		rFirstTermModules = new ListView<Module>();
		
		modulesUFirstTerm = FXCollections.observableArrayList(listUFirst);
		modulesRFirstTerm = FXCollections.observableArrayList(listRFirst);
		
		
		uFirstTermModules.setItems(modulesUFirstTerm);
		rFirstTermModules.setItems(modulesRFirstTerm);
		
		uFirstTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		rFirstTermModules.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		uFirstTermModules.setPrefSize(500, 400);
		rFirstTermModules.setPrefSize(500, 400);
		
		Label lblReserveFirst = new Label("Reserve 30 credits of term 1 modules");
		Label lblUFirst = new Label("Unselected Term 1 modules");
		Label lblRFirst = new Label("Reserved Term 1 modules");
		
		btnAddReserveFirst = new Button ("add");
		btnRemoveReserveFirst = new Button ("remove");
		btnConfirmReserveFirst = new Button ("confirm");
		
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setPercentWidth(50);
		
		ColumnConstraints column2 = new ColumnConstraints();
		column2.setPercentWidth(50);
		
		RowConstraints row1 = new RowConstraints();
		row1.setPercentHeight(90);
		
		RowConstraints row2 = new RowConstraints();
		row2.setPercentHeight(10);
		
		this.getColumnConstraints().addAll(column1,column2);
		this.getRowConstraints().addAll(row1,row2);
		
		VBox.setVgrow(uFirstTermModules, Priority.ALWAYS);
		VBox.setVgrow(rFirstTermModules, Priority.ALWAYS);

		//create Vbox1
		VBox vbox1 = new VBox(8);
		vbox1.setPadding(new Insets(10));
		vbox1.setAlignment(Pos.CENTER_LEFT);
		
		vbox1.getChildren().addAll(lblUFirst,uFirstTermModules);
		
		//create Vbox2
		VBox vbox2 = new VBox(8);
		vbox2.setPadding(new Insets(10));
		vbox2.setAlignment(Pos.CENTER_LEFT);
		
		vbox2.getChildren().addAll(lblRFirst,rFirstTermModules);
		

		
		//create HBox1
		HBox hbox1 = new HBox(8);
		hbox1.setPadding(new Insets(10));
		hbox1.setAlignment(Pos.CENTER_RIGHT);
		
		hbox1.getChildren().addAll(lblReserveFirst,btnAddReserveFirst,btnRemoveReserveFirst,btnConfirmReserveFirst);


		this.add(vbox1, 0, 0);
		this.add(vbox2, 1, 0);
		this.add(hbox1, 0, 1);
		
	}
	
	public Module getUnselectedFirst() {
		return uFirstTermModules.getSelectionModel().getSelectedItem();
	}
	
	public Module getReservedFirst() {
		return rFirstTermModules.getSelectionModel().getSelectedItem();
	}
	
	public void addFirstTermReserveModules(Module module) {
		modulesRFirstTerm.add(module);
		modulesUFirstTerm.remove(module);
	}
	
	
	public void removeFirstTermReserveModules(Module module) {
		modulesUFirstTerm.add(module);
		modulesRFirstTerm.remove(module);
	}
	
	public Set<Module> confirmFirstTermReserveModules() {
		Set<Module> reservedModules;
		reservedModules = new TreeSet<Module>();
		
			for (Module m: modulesRFirstTerm) {
				reservedModules.add(m);
			}
		return reservedModules;
	}
	
	public int getCredits() {
		int credits = 0;
		
		for (Module i: modulesRFirstTerm) {
			credits = credits + i.getModuleCredits();
		}
		return credits;
	}
	
	public void addModulesToListView(Collection<Module> Course, Set<Module> selectedModules) {
		modulesUFirstTerm.addAll(Course);
		modulesUFirstTerm.removeIf(m -> m.isMandatory() || !m.getDelivery().equals(Schedule.TERM_1));
		modulesUFirstTerm.removeIf(m -> selectedModules.contains(m));
	}
	
	public void clearContent() {
		modulesUFirstTerm.clear();
	}
	
	public void loadMoulesToListView(Set<Module> reservedModules) {
		modulesUFirstTerm.removeIf(m -> reservedModules.contains(m));
		modulesRFirstTerm.addAll(reservedModules);
		modulesRFirstTerm.removeIf(m -> !m.getDelivery().equals(Schedule.TERM_1));
	}
	
	public void addAddReserveFirstHandler(EventHandler<ActionEvent> handler) {
		btnAddReserveFirst.setOnAction(handler);
	}
	
	public void addRemoveReserveFirstHandler(EventHandler<ActionEvent> handler) {
		btnRemoveReserveFirst.setOnAction(handler);
	}
	
	public void addSubmitReserveFirstHandler(EventHandler<ActionEvent> handler) {
		btnConfirmReserveFirst.setOnAction(handler);
	}
}
