package controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Set;
import java.util.TreeSet;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Course;
import model.Schedule;
import model.Module;
import model.StudentProfile;
import view.ModuleSelectionToolRootPane;
import view.OverviewSelectionPane;
import view.ReserveModulesPane;
import view.ReserveModulesTerm1Pane;
import view.ReserveModulesTerm2Pane;
import view.CreateStudentProfilePane;
import view.ModuleSelectionPane;
import view.ModuleSelectionToolMenuBar;

public class ModuleSelectionToolController {

	//fields to be used throughout class
	private ModuleSelectionToolRootPane view;
	private StudentProfile model;
	
	private CreateStudentProfilePane cspp;
	private ModuleSelectionToolMenuBar mstmb;
	private ModuleSelectionPane msp;
	private ReserveModulesPane rmp;
	private ReserveModulesTerm1Pane rmf;
	private ReserveModulesTerm2Pane rms;
	private OverviewSelectionPane ops;
	
	public ModuleSelectionToolController(ModuleSelectionToolRootPane view, StudentProfile model) {
		//initialise view and model fields
		this.view = view;
		this.model = model;
		
		//initialise view subcontainer fields
		cspp = view.getCreateStudentProfilePane();
		mstmb = view.getModuleSelectionToolMenuBar();
		msp = view.getModuleSelectionPane();
		rmp = view.getReserveModulesPane();
		rmf = rmp.getReserveModulesTerm1Pane();
		rms = rmp.getReserveModulesTerm2Pane();
		ops = view.getOverviewSelectionPane();
		
		//add courses to combobox in create student profile pane using the generateAndReturnCourses helper method below
		cspp.addCoursesToComboBox(generateAndReturnCourses());

		//attach event handlers to view using private helper method
		this.attachEventHandlers();	
	}

	
	//helper method - used to attach event handlers
	private void attachEventHandlers() {
		//attach an event handler to the create student profile pane
		cspp.addCreateStudentProfileHandler(new CreateStudentProfileHandler());
		msp.addAddFirstHandler(new AddFirstHandler());
		msp.addAddSecondHandler(new AddSecondHandler());
		msp.addRemoveFirstHandler(new RemoveFirstHandler());
		msp.addRemoveSecondHandler(new RemoveSecondHandler());
		msp.addSubmitHandler(new SubmitHandler());
		msp.addResetHandler(new ResetHandler());
		rmf.addAddReserveFirstHandler(new AddReserveFirstHandler());
		rmf.addRemoveReserveFirstHandler(new RemoveReserveFirstHandler());
		rmf.addSubmitReserveFirstHandler(new SubmitReserveFirstHandler());
		rms.addAddReserveSecondHandler(new AddReserveSecondHandler());
		rms.addRemoveReserveSecondHandler(new RemoveReserveSecondHandler());
		rms.addSubmitReserveSecondHandler(new SubmitReserveSecondHandler());
		ops.addSaveOverview(new SaveOverview());
		mstmb.addLoadHandler(new LoadHandler());
		mstmb.addSaveHandler(new SaveHandler());
		mstmb.addAboutHandler(new AboutHandler());
		
		
		//attach an event handler to the menu bar that closes the application
		mstmb.addExitHandler(e -> System.exit(0));
	}
	
	//event handler (currently empty), which can be used for creating a profile
	private class CreateStudentProfileHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			model.setStudentName(cspp.getStudentName());
			model.setStudentCourse(cspp.getSelectedCourse());
			model.setStudentEmail(cspp.getStudentEmail());
			model.setStudentPnumber(cspp.getStudentPnumber());
			model.setSubmissionDate(cspp.getStudentDate());
			
			//alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Student Profile created", "Successfully created student profile");
			
			msp.addModulesToListView(cspp.getSelectedCourse().getAllModulesOnCourse());
			msp.creditsFirst();
			msp.creditsSecond();
			view.changeTab(1);
		}
	}
	
	private class AddFirstHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			msp.addFirstTermModule(msp.getUnselectedFirst());
			msp.creditsFirst();
		}
	}
	
	private class AddSecondHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			msp.addSecondTermModule(msp.getUnselectedSecond());
			msp.creditsSecond();
		}
		}
	
	private class RemoveFirstHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			msp.removeFirstTermModule(msp.getSelectedFirst());
			msp.creditsFirst();
		}
	}
	
	private class RemoveSecondHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			msp.removeSecondTermModule(msp.getSelectedSecond());
			msp.creditsSecond();
		}
	}
	
	private class SubmitHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			
			if (msp.creditsFirst() == 60 && msp.creditsSecond() == 60) {
			Set<Module> modules = new TreeSet<Module>();
			modules = msp.setModules();
			for (Module i : modules) {
			model.addSelectedModule(i);
			}
			rmf.addModulesToListView(cspp.getSelectedCourse().getAllModulesOnCourse(),model.getAllSelectedModules());
			rms.addModulesToListView(cspp.getSelectedCourse().getAllModulesOnCourse(),model.getAllSelectedModules());
			view.changeTab(2);
			} else {
				alertDialogBuilder(AlertType.ERROR,"Error Dialog","Incorrect credit amount","You should have 60 credits for first");
			}
		}
	}
	
	private class ResetHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			msp.clearContent();
			msp.addModulesToListView(cspp.getSelectedCourse().getAllModulesOnCourse());
			msp.creditsFirst();
			msp.creditsSecond();
		}
	}
	
	private class AddReserveFirstHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			rmf.addFirstTermReserveModules(rmf.getUnselectedFirst());
		}
	}
	
	private class RemoveReserveFirstHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			rmf.removeFirstTermReserveModules(rmf.getReservedFirst());
		}
	}
	
	private class SubmitReserveFirstHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			Set<Module> modules = new TreeSet<Module>();
			modules = rmf.confirmFirstTermReserveModules();
			if (rmf.getCredits() == 30) {
				for (Module i: modules) {
					model.addReservedModule(i);
				}
				rmp.changePane();
			}else {
				alertDialogBuilder(AlertType.ERROR,"Error Dialog","Incorrect credit amount","You should have 30 credits for reserve modules");
			}
		}
	}

	private class AddReserveSecondHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			rms.addSecondTermReserveModules(rms.getUnselectedSecond());
		}
	}

	private class RemoveReserveSecondHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			rms.removeSecondTermReserveModules(rms.getReservedSecond());
		}
	}

	private class SubmitReserveSecondHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			Set<Module> modules = new TreeSet<Module>();
			modules = rms.confirmSecondTermReserveModules();
			if (rms.getCredits() == 30) {
				for (Module i: modules) {
					model.addReservedModule(i);
				}
				ops.clearContent();
				ops.addStudentToListView(model);
				ops.addSelectedModulesToListView(model.getAllSelectedModules());
				ops.addReservedModulesToListView(model.getAllReservedModules());
				view.changeTab(3);
			}else {
				alertDialogBuilder(AlertType.ERROR,"Error Dialog","Incorrect credit amount","You should have 30 credits for reserve modules");
			}
		}
	}
	
	private class SaveOverview implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			FileWriter file;
			
				try {
					file = new FileWriter(model.getStudentPnumber() + ".txt");
					PrintWriter output = new PrintWriter(file);
					output.print(model.toString());
					output.close();
					alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Save success", "Options saved to " + model.getStudentPnumber() + ".txt");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	
	private class LoadHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			String fileName =  "StudentProfile.dat";
			try (ObjectInputStream objStream = new ObjectInputStream(new FileInputStream(fileName))) {
				model = (StudentProfile) objStream.readObject();
				
				msp.clearContent();
				rmf.clearContent();
				rms.clearContent();
				ops.clearContent();	
				
				msp.addModulesToListView(model.getStudentCourse().getAllModulesOnCourse());
				
				if (!model.getAllSelectedModules().isEmpty()) {
					msp.LoadModulesToListView(model.getAllSelectedModules());
					if(msp.creditsFirst() != 60 || msp.creditsSecond() != 60) {
						model.getAllSelectedModules().clear();
					}
					msp.creditsFirst();
					msp.creditsSecond();
				}
					rmf.addModulesToListView(model.getStudentCourse().getAllModulesOnCourse(), model.getAllSelectedModules());
					rms.addModulesToListView(model.getStudentCourse().getAllModulesOnCourse(), model.getAllSelectedModules());
				
				
				if (!model.getAllReservedModules().isEmpty()) {
					rmf.loadMoulesToListView(model.getAllReservedModules());
					rms.loadMoulesToListView(model.getAllReservedModules());
					if(rmf.getCredits() != 30 ) {
						model.getAllReservedModules().removeIf(m -> m.getDelivery().equals(Schedule.TERM_1));
					}
					
					if(rms.getCredits() != 30 ) {
						model.getAllReservedModules().removeIf(m -> m.getDelivery().equals(Schedule.TERM_2));
					}
				}
				
				ops.addStudentToListView(model);
				ops.addSelectedModulesToListView(model.getAllSelectedModules());
				ops.addReservedModulesToListView(model.getAllReservedModules());

				alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Load success", "Loaded profile from StudentProfile.dat");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	private class SaveHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			String fileName ="StudentProfile.dat";
			
			Set<Module> modules = new TreeSet<Module>();
			modules = msp.setModules();
			for (Module i : modules) {
				if (i.isMandatory() == false) {
					model.addSelectedModule(i);
				}
			}
			
			Set<Module> reserveModulesFirst = new TreeSet<Module>();
			reserveModulesFirst = rmf.confirmFirstTermReserveModules();
			
			for (Module i:  reserveModulesFirst) {
				model.addReservedModule(i);
			}
			
			Set<Module> reserveModulesSecond = new TreeSet<Module>();
			reserveModulesSecond = rms.confirmSecondTermReserveModules();
			
			for (Module i:  reserveModulesSecond) {
				model.addReservedModule(i);
			}
			
			
			try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName))) {
				output.writeObject(model);
				output.flush();
				alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Save success", "Register saved to StudentProfile.dat");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	private class AboutHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			alertDialogBuilder(AlertType.INFORMATION, "About Dialog", "About", "This program allows you to enter your personal details and select your course allowing you to pick your modules and see your mandatory ones, 60 credits for first term and 60 for second term as well as 30 credits reserve modules for both terms");
		}
	}
		


	//helper method - generates course and module data and returns courses within an array
	private Course[] generateAndReturnCourses() {
		Module imat3423 = new Module("IMAT3423", "Systems Building: Methods", 15, true, Schedule.TERM_1);
		Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Schedule.YEAR_LONG);
		Module ctec3902_SoftEng = new Module("CTEC3902", "Rigorous Systems", 15, true, Schedule.TERM_2);	
		Module ctec3902_CompSci = new Module("CTEC3902", "Rigorous Systems", 15, false, Schedule.TERM_2);
		Module ctec3110 = new Module("CTEC3110", "Secure Web Application Development", 15, false, Schedule.TERM_1);
		Module ctec3605 = new Module("CTEC3605", "Multi-service Networks 1", 15, false, Schedule.TERM_1);	
		Module ctec3606 = new Module("CTEC3606", "Multi-service Networks 2", 15, false, Schedule.TERM_2);	
		Module ctec3410 = new Module("CTEC3410", "Web Application Penetration Testing", 15, false, Schedule.TERM_2);
		Module ctec3904 = new Module("CTEC3904", "Functional Software Development", 15, false, Schedule.TERM_2);
		Module ctec3905 = new Module("CTEC3905", "Front-End Web Development", 15, false, Schedule.TERM_2);
		Module ctec3906 = new Module("CTEC3906", "Interaction Design", 15, false, Schedule.TERM_1);
		Module ctec3911 = new Module("CTEC3911", "Mobile Application Development", 15, false, Schedule.TERM_1);
		Module imat3410 = new Module("IMAT3104", "Database Management and Programming", 15, false, Schedule.TERM_2);
		Module imat3406 = new Module("IMAT3406", "Fuzzy Logic and Knowledge Based Systems", 15, false, Schedule.TERM_1);
		Module imat3611 = new Module("IMAT3611", "Computer Ethics and Privacy", 15, false, Schedule.TERM_1);
		Module imat3613 = new Module("IMAT3613", "Data Mining", 15, false, Schedule.TERM_1);
		Module imat3614 = new Module("IMAT3614", "Big Data and Business Models", 15, false, Schedule.TERM_2);
		Module imat3428_CompSci = new Module("IMAT3428", "Information Technology Services Practice", 15, false, Schedule.TERM_2);


		Course compSci = new Course("Computer Science");
		compSci.addModuleToCourse(imat3423);
		compSci.addModuleToCourse(ctec3451);
		compSci.addModuleToCourse(ctec3902_CompSci);
		compSci.addModuleToCourse(ctec3110);
		compSci.addModuleToCourse(ctec3605);
		compSci.addModuleToCourse(ctec3606);
		compSci.addModuleToCourse(ctec3410);
		compSci.addModuleToCourse(ctec3904);
		compSci.addModuleToCourse(ctec3905);
		compSci.addModuleToCourse(ctec3906);
		compSci.addModuleToCourse(ctec3911);
		compSci.addModuleToCourse(imat3410);
		compSci.addModuleToCourse(imat3406);
		compSci.addModuleToCourse(imat3611);
		compSci.addModuleToCourse(imat3613);
		compSci.addModuleToCourse(imat3614);
		compSci.addModuleToCourse(imat3428_CompSci);

		Course softEng = new Course("Software Engineering");
		softEng.addModuleToCourse(imat3423);
		softEng.addModuleToCourse(ctec3451);
		softEng.addModuleToCourse(ctec3902_SoftEng);
		softEng.addModuleToCourse(ctec3110);
		softEng.addModuleToCourse(ctec3605);
		softEng.addModuleToCourse(ctec3606);
		softEng.addModuleToCourse(ctec3410);
		softEng.addModuleToCourse(ctec3904);
		softEng.addModuleToCourse(ctec3905);
		softEng.addModuleToCourse(ctec3906);
		softEng.addModuleToCourse(ctec3911);
		softEng.addModuleToCourse(imat3410);
		softEng.addModuleToCourse(imat3406);
		softEng.addModuleToCourse(imat3611);
		softEng.addModuleToCourse(imat3613);
		softEng.addModuleToCourse(imat3614);

		Course[] courses = new Course[2];
		courses[0] = compSci;
		courses[1] = softEng;

		return courses;
	}
	
	private void alertDialogBuilder(AlertType type, String title, String header, String content) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.showAndWait();
	}

}
