package model;

import java.io.Serializable;

public enum Schedule implements Serializable  {
	TERM_1, TERM_2, YEAR_LONG
}
